# retinanet > 2024-03-20 8:01am
https://universe.roboflow.com/yolo-5lgan/retinanet-7xqxc

Provided by a Roboflow user
License: CC BY 4.0

